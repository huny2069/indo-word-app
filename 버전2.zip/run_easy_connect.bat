@echo off
setlocal
cd /d "%~dp0"

title IndoLearn Ultra Connector (Cloudflare)
echo ======================================================
echo   IndoLearn Easy Connect Mode (Cloudflare Tunnel)
echo ======================================================
echo.

echo [Step 1] Closing existing node processes...
taskkill /f /im node.exe >nul 2>&1

echo [Step 2] Initializing Server on Port 5173...
:: Run Vite server using http (not https) for tunnel compatibility
start /b cmd /c "npm.cmd run dev -- --port 5173 --host"

echo [Step 3] Creating Public URL via Cloudflare...
echo Wait for "https://xxxxxxxx.trycloudflare.com" link.
echo.

:: Use 127.0.0.1 instead of localhost to avoid IPv6 issues ([::1])
npx cloudflared tunnel --url http://127.0.0.1:5173

pause
