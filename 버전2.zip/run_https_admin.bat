@echo off
setlocal
cd /d "%~dp0"

title IndoLearn HTTPS Admin Setup
echo ======================================================
echo   IndoLearn HTTPS Admin Setup (Administrator)
echo ======================================================
echo.

echo [Step 1] Allowing Port 5443 in Windows Firewall...
netsh advfirewall firewall add rule name="IndoLearn_HTTPS_5443" dir=in action=allow protocol=TCP localport=5443 >nul 2>&1
echo Done.

echo.
echo [Step 2] Installing Dependencies...
call npm.cmd install -D @vitejs/plugin-basic-ssl@^1.1.0 --legacy-peer-deps

echo.
echo [Step 3] Running HTTPS Server...
echo If you see a privacy warning in browser, click Advanced - Proceed.
echo.

:: We use 'call' to prevent the script from exiting immediately
call npm.cmd run dev

echo.
echo Server Stopped.
pause
