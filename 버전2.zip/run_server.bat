@echo off
title IndoLearn Server Runner
echo ======================================================
echo   인도네시아어 단어장 (IndoLearn) 서버를 실행합니다...
echo ======================================================
echo.
echo [안내] 서버가 켜진 상태에서만 앱 접속이 가능합니다.
echo [안내] 종료하시려면 이 창을 닫거나 Ctrl+C를 누르세요.
echo.
npm run dev
pause
